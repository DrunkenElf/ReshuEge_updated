package com.ilnur.DownloadTasks

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AlertDialog
import android.util.Log
import android.widget.Toast

import org.json.JSONObject

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL
import java.net.URLEncoder
import java.util.ArrayList

import javax.net.ssl.HttpsURLConnection

import com.ilnur.Protocol
import com.ilnur.R
import com.ilnur.SearchResultActivity
import com.ilnur.utils.StreamReader


class SearchTask(internal var context: Context, internal var subject_prefix: String, internal var query: String) : AsyncTask<String, Int, ArrayList<Int>>() {

    internal lateinit var progress: ProgressDialog
    internal var serverError = false

    override fun onPreExecute() {
        progress = ProgressDialog(context)
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER)

        progress.setMessage("Поиск заданий")

        try {
            progress.show()
            progress.setCancelable(false)

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun doInBackground(vararg strings: String): ArrayList<Int> {


        val questions = ArrayList<Int>()

        try {
            val performedQuery = query.toByteArray(charset("UTF-8"))
            query = String(performedQuery, charset("UTF-8"))
            val response = loadAPI("search&query=", query)

            val taskNumbers = JSONObject(response).getJSONArray("data")
            for (i in 0 until taskNumbers.length()) {
                questions.add(taskNumbers.getInt(i))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d("myLogs", e.toString())
            serverError = true
        }

        return questions
    }

    override fun onPostExecute(questions: ArrayList<Int>) {
        super.onPostExecute(questions)
        if (!serverError) {
            try {

                var result = arrayOfNulls<Int>(questions.size)
                result = questions.toTypedArray<Int?>()

                progress.dismiss()
                if (result.size == 0) {
                    Toast.makeText(context, "Ничего не найдено", Toast.LENGTH_SHORT).show()
                } else {
                    val array = IntArray(result.size)
                    for (i in result.indices) {
                        array[i] = result[i]!!
                    }
                    val intent = Intent(context, SearchResultActivity::class.java)
                    intent.putExtra("results", array)
                    intent.putExtra("subject_prefix", subject_prefix)
                    context.startActivity(intent)
                }

            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("myLogs", e.toString())
            }

        } else {
            progress.dismiss()
            showMessage("Сервер РЕШУ ЕГЭ временно недоступен.", context.getString(R.string.error))
        }
    }

    fun loadAPI(APIRequest: String, query: String): String? {

        var str: String? = null
        var tryesCount = 0
        while (str == null && tryesCount != 10)
            try {
                tryesCount++
                val url: URL
                url = URL("https://" + subject_prefix + "-ege.sdamgia.ru/api?type=" + APIRequest + URLEncoder.encode(query, "UTF-8") + "&" + Protocol.protocolVersion)
                val urlConnection = url.openConnection() as HttpsURLConnection
                val `in` = BufferedReader(InputStreamReader(urlConnection.inputStream))
                str = StreamReader().readLines(`in`)


            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("myLogs", "$APIRequest $query $e")
            }

        return str
    }

    fun showMessage(title: String, message: String) {

        val ad = AlertDialog.Builder(context)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setPositiveButton("Продолжить") { dialog, arg1 -> }

        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()
    }

}
