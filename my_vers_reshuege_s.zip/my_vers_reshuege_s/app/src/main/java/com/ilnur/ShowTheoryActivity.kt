package com.ilnur

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import com.ilnur.DataBase.MyDB

//import com.ilnur.DataBase.MyDB1

class ShowTheoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_theory)
        val subj_pref = intent.getStringExtra("subj_pref")
        val id = intent.getStringExtra("id")
        //Log.d("myLogs", theoryText);
        showTheory(subj_pref, id)
    }

    private fun showTheory(table: String, id: String) {
        val data = MyDB.getTemasData(table, id)
        val showWV = findViewById<View>(R.id.theoryView) as WebView
        showWV.settings.builtInZoomControls = true
        showWV.settings.displayZoomControls = false
        showWV.loadDataWithBaseURL(null, data, "text/html", "utf-8", null)
    }


}
