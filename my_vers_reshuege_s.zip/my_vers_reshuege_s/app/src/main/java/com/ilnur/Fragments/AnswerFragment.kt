package com.ilnur.Fragments

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.preference.PreferenceManager
import androidx.fragment.app.Fragment
import android.text.InputType
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

import java.util.ArrayList

import com.ilnur.FirstPoint
import com.ilnur.R


class AnswerFragment : Fragment() {

    private var mListener: OnFragmentInteractionListener? = null
    internal lateinit var answer: String
    internal var type: Int = 0
    internal var questionNumber: Int = 0
    internal var task: Int = 0
    internal var category: Int = 0
    internal var NEXT_QUESTION: Byte = 1
    internal var SHOW_COMMENT: Byte = 2
    internal var SHOW_CRIT: Byte = 3
    internal var show_comment: Boolean = false
    internal lateinit var pointObj: FirstPoint

    val maxPoints: Int
        get() {
            val max: Int
            max = pointObj.maxPoints()
            return max
        }
    //String[] points;

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_answer, null)
        initializeButtons(v)
        initializeSettings()
        initializePoints()
        return v
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        try {
            mListener = activity as OnFragmentInteractionListener
        } catch (e: ClassCastException) {
            throw ClassCastException("$activity должен реализовывать интерфейс OnFragmentInteractionListener")
        }

    }

    interface OnFragmentInteractionListener {
        fun onFragmentInteraction(answer: Boolean)
        fun onFragmentInteraction(yourAnswer: String, point: String, pluses: String, color: String)
        fun onFragmentInteraction(command: Byte)
    }

    fun sendResult(answer: Boolean, yourAnswer: String, point: String, pluses: String, color: String) {
        mListener!!.onFragmentInteraction(answer)
        mListener!!.onFragmentInteraction(yourAnswer, point, pluses, color)
    }

    fun setAnswer(answer: String, type: Int, questionNumber: Int, category: Int) {
        this.answer = answer
        this.type = type
        this.category = category
        this.questionNumber = questionNumber
        val answerText = view!!.findViewById<View>(R.id.answerText) as EditText
        answerText.setText("")
        answerText.isEnabled = true
        val answerButton = activity!!.findViewById<View>(R.id.answerButton) as Button
        val nextButton = activity!!.findViewById<View>(R.id.nextButton) as Button
        val commentButton = activity!!.findViewById<View>(R.id.commentButton) as Button
        answerButton.visibility = View.VISIBLE
        nextButton.visibility = View.GONE
        commentButton.visibility = View.GONE
    }

    fun setYourAnswer(yourAnswer: String) {
        val answerText = view!!.findViewById<View>(R.id.answerText) as EditText
        answerText.setText("Ваш ответ: $yourAnswer")
        answerText.isEnabled = false
        val answerButton = activity!!.findViewById<View>(R.id.answerButton) as Button
        val nextButton = activity!!.findViewById<View>(R.id.nextButton) as Button
        val commentButton = activity!!.findViewById<View>(R.id.commentButton) as Button
        val pointSpinner = view!!.findViewById<View>(R.id.pointSpinner) as Spinner
        val pointsButton = view!!.findViewById<View>(R.id.pointsButton) as Button
        answerButton.visibility = View.GONE
        nextButton.visibility = View.VISIBLE
        pointSpinner.visibility = View.GONE
        pointsButton.visibility = View.GONE
        if (show_comment)
            commentButton.visibility = View.VISIBLE
        else
            commentButton.visibility = View.GONE
    }

    private fun checkAnswer(answer: String, type: Int, category: Int) {
        var answer = answer
        val answerText = view!!.findViewById<View>(R.id.answerText) as EditText
        var yourAnswer = answerText.text.toString()

        //answer = answer.toLowerCase();
        if (answerText.inputType == InputType.TYPE_CLASS_PHONE) {
            answer = answer.replace(".", "")
        }
        answer = answer.replace(" ", "")
        answer = answer.replace(".", ",")
        //yourAnswer = yourAnswer.toLowerCase();
        yourAnswer = yourAnswer.replace(" ", "")
        yourAnswer = yourAnswer.replace(".", ",")
        if (yourAnswer.contentEquals("")) yourAnswer = "Не решено"



        if (type != 3) {
            val point = pointObj.getFirtsPoint(yourAnswer, answer, questionNumber, category)
            val pluses = pointObj.pluses
            var color = pointObj.color
            if (yourAnswer.contentEquals("Не решено")) color = "white"
            sendResult(pointObj.checkAnswer(), yourAnswer, point, pluses, color!!)
        } else {
            val pointSpinner = activity!!.findViewById<View>(R.id.pointSpinner) as Spinner
            val point = pointSpinner.selectedItemPosition
            if (questionNumber < pointObj.task_count()) {
                if (Integer.parseInt(pointObj.get_max(questionNumber)) == point) {
                    sendResult(true, "Часть С", Integer.toString(point), "+", "green")
                } else if (Integer.parseInt(pointObj.get_max(questionNumber)) == 0)
                    sendResult(false, "Часть С", Integer.toString(point), "-", "red")
                else
                    sendResult(false, "Часть С", Integer.toString(point), "-", "yellow")
            } else
                sendResult(false, "Часть С", Integer.toString(point), "-", "yellow")
        }
        answerText.setText("")
    }

    fun nextQuestion() {
        mListener!!.onFragmentInteraction(NEXT_QUESTION)
    }

    fun showComment() {
        mListener!!.onFragmentInteraction(SHOW_COMMENT)
    }

    fun setButtonsVisibility(type: Int) {
        val answerButton = activity!!.findViewById<View>(R.id.answerButton) as Button
        val nextButton = activity!!.findViewById<View>(R.id.nextButton) as Button
        val commentButton = activity!!.findViewById<View>(R.id.commentButton) as Button
        val answerText = view!!.findViewById<View>(R.id.answerText) as EditText
        val pointSpinner = view!!.findViewById<View>(R.id.pointSpinner) as Spinner
        val pointsButton = view!!.findViewById<View>(R.id.pointsButton) as Button

        if (type == 3) {
            nextButton.visibility = View.VISIBLE
            if (show_comment)
                commentButton.visibility = View.VISIBLE
            else
                commentButton.visibility = View.GONE

            val pointsArray = ArrayList<String>()
            var count = 0
            Log.d("QUnum", "" + questionNumber)
            if (questionNumber < pointObj.task_count()) {
                count = Integer.parseInt(pointObj.get_max(questionNumber + 1))
                Log.d("POINTS", "" + count)
            }
            for (i in 0..count) {
                pointsArray.add(Integer.toString(i))
            }

            val adapter = ArrayAdapter(activity!!, android.R.layout.simple_spinner_item, pointsArray)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            pointSpinner.adapter = adapter
            pointSpinner.visibility = View.VISIBLE
            pointsButton.visibility = View.VISIBLE

            answerButton.visibility = View.GONE
            answerText.visibility = View.GONE
            answerText.isEnabled = false
        } else {
            pointSpinner.visibility = View.GONE
            pointsButton.visibility = View.GONE
            answerText.visibility = View.VISIBLE
        }


    }

    internal fun initializeButtons(v: View) {

        val answerButton = v.findViewById<View>(R.id.answerButton) as Button
        answerButton.setOnClickListener { v ->
            checkAnswer(answer, type, category)
            val imm = activity!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(v.windowToken,
                    InputMethodManager.HIDE_NOT_ALWAYS)
        }

        val nextButton = v.findViewById<View>(R.id.nextButton) as Button
        nextButton.setOnClickListener { nextQuestion() }

        val commentButton = v.findViewById<View>(R.id.commentButton) as Button
        commentButton.setOnClickListener { showComment() }

        val pointsButton = v.findViewById<View>(R.id.pointsButton) as Button
        pointsButton.setOnClickListener { checkAnswer(answer, type, category) }
    }

    internal fun initializeSettings() {
        val settingsPref = PreferenceManager.getDefaultSharedPreferences(activity)

        val section = activity!!.intent.getStringExtra("section")

        if (section.contentEquals("Варианты") || section.contentEquals("Каталог заданий"))
            show_comment = settingsPref.getBoolean("show_comment", false)
        else if (section.contentEquals("Режим экзамена")) show_comment = false
    }

    internal fun initializePoints() {
        val subject_prefix = activity!!.intent.getStringExtra("subject_prefix")
        //points = getResources().getStringArray(getResources().getIdentifier(subject_prefix + "_points", "array", getActivity().getPackageName()));
        pointObj = FirstPoint(subject_prefix)
    }


}
