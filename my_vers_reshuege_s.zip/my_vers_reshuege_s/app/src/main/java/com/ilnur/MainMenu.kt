package com.ilnur


//import vdd.test.Fragments.SubjectsFragment;
import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteException
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.transition.Slide
import android.util.Log
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.ilnur.DataBase.MyDB
//import com.ilnur.DataBase.MyDB1
import com.ilnur.DataBase.QuestionsDataBaseHelper
import com.ilnur.DownloadTasks.*
import com.ilnur.Fragments.*
import com.ilnur.Session.Session
import com.ilnur.Session.SessionState
import com.ilnur.Session.Settings
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class MainMenu : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener, SubjectsFragment.OnFragmentInteractionListener, StartPageFragment.OnFragmentInteractionListener, SubjectsTheoryFragment.OnFragmentInteractionListener, SubjectSearchFragment.OnFragmentInteractionListener, SubjectThemesFragment.OnFragmentInteractionListener {

    internal lateinit var container: FrameLayout
    internal lateinit var fManager: FragmentManager
    internal lateinit var fTransaction: FragmentTransaction
    internal var itemSelected: String? = "РЕШУ ЕГЭ"
    internal lateinit var context: Context
    private var mHandler: Handler? = null
    lateinit var fragment: Fragment

    private fun setupAnim() {
        if (Build.VERSION.SDK_INT >= 21) {
            val toRight = Slide()
            toRight.slideEdge = Gravity.RIGHT
            toRight.duration = 300

            val toLeft = Slide()
            toLeft.slideEdge = Gravity.LEFT
            toLeft.duration = 300

            //когда переходишь на новую
            window.exitTransition = toLeft
            window.enterTransition = toRight

            //когда нажимаешь с другого назад и открываешь со старого
            window.returnTransition = toRight
            window.reenterTransition = toRight
        }
    }

    override fun onStart() {
        super.onStart()
        //serReceiver()
    }

    /*fun serReceiver() {
        val receiver = SubjAdapter.BroadIntReceiver()
        val intentFilter = IntentFilter()
        intentFilter.addAction("done")

        LocalBroadcastManager.getInstance(context).registerReceiver(receiver, intentFilter)
    }*/

    override fun onSaveInstanceState(outState: Bundle?, outPersistentState: PersistableBundle?) {
        super.onSaveInstanceState(outState, outPersistentState)
        supportFragmentManager.putFragment(outState!!, "myFr", fragment)
    }

    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var importance = NotificationManager.IMPORTANCE_HIGH
            var channel = NotificationChannel("77", "РЕШУ ЕГЭ", importance).apply {
                description = "Загрузка предмета"
                //enableLights(true)
                setSound(null, null)
                //lightColor = Color.RED
                setShowBadge(true)
            }
            // Register the channel with the system
            var notificationManager: NotificationManager =
                    getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)

            importance = NotificationManager.IMPORTANCE_LOW
            channel = NotificationChannel("33", "РЕШУ ЕГЭ", importance).apply {
                description = "Загрузка предмета"
                //enableLights(true)
                //lightColor = Color.RED
                setShowBadge(true)
            }
            // Register the channel with the system
            notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    //@SuppressLint("RestrictedApi")
    //@SuppressLint("RestrictedApi")
    @SuppressLint("RestrictedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        instance = savedInstanceState
        setupAnim()
        setContentView(R.layout.activity_main_menu)
        val toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        context = this
        mHandler = Handler()

        if (savedInstanceState != null) {
            if (savedInstanceState.containsKey("myFr"))
                fragment = supportFragmentManager.getFragment(savedInstanceState, "myFr")!!
        }

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        container = findViewById<View>(R.id.container) as FrameLayout
        fManager = supportFragmentManager
        val db = MyDB(context)
        MyDB.init(db, false)

        try {
            user = MyDB.getUser()
        } catch (e: SQLiteException){
            user = User(null, null, null)
        }

        val si = SubjInfo()
        si.context = context
        si.check_subject_data()

        val fab = findViewById<View>(R.id.fab) as FloatingActionButton
        fab.setOnClickListener {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ege.sdamgia.ru/"))
            startActivity(browserIntent)
        }

        setVersionPreferences()
        val content: CoordinatorLayout = findViewById(R.id.coordinator_layout)

        val drawer = findViewById<View>(R.id.drawer_layout) as DrawerLayout
        val toggle = ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)

        //drawer.setDrawerListener(toggle)
        drawer.setScrimColor(Color.TRANSPARENT)
        val drawerToggle: ActionBarDrawerToggle = object : ActionBarDrawerToggle(
                this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        ) {
            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                super.onDrawerSlide(drawerView, slideOffset)
                val slideX = drawerView.width * slideOffset
                content.translationX = slideX
                //content.scaleX = 1 - (slideOffset / 6f)
                //content.scaleY = 1 - (slideOffset / 6f)
            }

        }
        drawer.drawerElevation = 4f
        drawer.addDrawerListener(drawerToggle)
        toggle.syncState()


        val navigationView = findViewById<View>(R.id.nav_view) as NavigationView
        navigationView.setNavigationItemSelectedListener(this)

       /* val mAppBarConfiguration = AppBarConfiguration.Builder(
                R.id.nav_home)
                .setDrawerLayout(drawer)
                .build()

        val navController = Navigation.findNavController(this, R.id.container)
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration)
        NavigationUI.setupWithNavController(navigationView, navController)*/

        if (savedInstanceState != null) {
            itemSelected = savedInstanceState.getString("itemSelected")
            supportActionBar!!.setTitle(itemSelected)
        } else {
            val startFragment = StartPageFragment()
            //fab.attachToListView(startFragment);
            /*if (instance == null){
                instance = Bundle()
            }
            instance!!.putString("itemSelected", "START")
            startFragment.arguments = instance
            supportFragmentManager.beginTransaction()
                    .setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.from_left, R.anim.to_right)
                    .replace(R.id.container, startFragment)
                    .addToBackStack("START")
                    .commitAllowingStateLoss()*/
            //overridePendingTransition(R.anim.enter_from_right, R.anim.to_right)
            setFragment(startFragment, "START", savedInstanceState)
        }

        if (!itemSelected!!.contentEquals(getString(R.string.app_name))) {
            fab.visibility = View.GONE
        }

        if (user.login == null || user.password == null) {
            val logAct = Intent(this, LoginActivity::class.java)
           /* if (Build.VERSION.SDK_INT > 20) {
                val options = ActivityOptions.makeSceneTransitionAnimation(this)
                startActivity(logAct, options.toBundle())
            } else {
                startActivity(logAct)
            }*/
            startActivity(Intent(this, LoginActivity::class.java))
            Log.d("main noUser", "log or pas null")
        } else {
            /*
             * проверить на логирование
             * ЕСЛИ тру - продолжить, фолс - написать причину в тосте и продолжить
             * */
            if (Connection.hasConnection(this)) {
                Log.d("main hascon", "has connection")
                UserLoginTask(user.login, user.password, savedInstanceState).execute()
            } else {
                Log.d("main noCon", "no connection")
                val sessionObject = Session("", SessionState.anonymus)
                val settings = Settings()
                settings.setSession(sessionObject, context)
                settings.setLoginAndPassword("", "", context)
                Toast.makeText(context, "Для авторизации необобходимо подключение к интернету", Toast.LENGTH_SHORT).show()
            }
        }

        /* val menu = navigationView.menu
         val menu_item = menu.findItem(R.id.dark_theme_switch)
         val switch = menu_item.actionView as Switch
         switch.setOnCheckedChangeListener{ buttonView, isChecked ->
             if (isChecked)
                 AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
             else
                 AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
          }*/

        val updatePref = getSharedPreferences("updateShown", AppCompatActivity.MODE_PRIVATE)


        /*if (Connection.hasConnection(this)) {
            val settings = Settings()
            if (!settings.getFirstStartFlag(context)) {
                // Construct the LicenseCheckerCallback. The library calls this when done.
                Log.d("HASconn", "update")
                checkUpdate()
                settings.setFirstStartFlag(true, context)
            }
        }*/

        val ed = updatePref.edit()
        ed.putBoolean("shown", false)
        ed.apply()

        instance = savedInstanceState
    }


    override fun onBackPressed() {
        val drawer = findViewById<View>(R.id.drawer_layout) as DrawerLayout
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)

        } else if (fManager.backStackEntryCount != 1) {
            Log.d("myLogs", Integer.toString(fManager.backStackEntryCount))
            fManager.popBackStack()
            if (fManager.backStackEntryCount == 2) {
                supportActionBar!!.title = getString(R.string.app_name)
                itemSelected = getString(R.string.app_name)
                val fab = findViewById<View>(R.id.fab) as FloatingActionButton
                fab.show()
                val animation = AnimationUtils.loadAnimation(this, R.anim.slide_in_up)
                fab.startAnimation(animation)
                Log.d("back","2")
                //StartPageFragment startFragment = new StartPageFragment();
                //setFragment(startFragment, "START");
            } else {
                val handler = Handler()
                val r = Runnable {
                    if (drawer.isDrawerOpen(GravityCompat.START))
                        drawer.closeDrawer(GravityCompat.START)
                }
                handler.postDelayed(r, 130)
                supportActionBar!!.title = itemSelected
            }
        } else
            showMessage("Выход", "Вы уверены, что хотите выйти?")

        createDataBaseIfNotExist()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId


        if (id == R.id.action_settings) {
            hideStartPage()
            val stFragment = SettingsFragment()
            setFragment(stFragment, null, instance)
            supportActionBar!!.title = "Настройки"
            return true
        }

        return super.onOptionsItemSelected(item)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        val id = item.itemId

        //val sFragment = SubjectsFragment()
        clearBackStack()
        val handler = Handler()
        val r = Runnable {
            val drawer = findViewById<View>(R.id.drawer_layout) as DrawerLayout
            drawer.closeDrawer(GravityCompat.START)
        }
        handler.postDelayed(r, 200)
        if (id == R.id.nav_search) {
            itemSelected = "Поиск"
            val searchFragment = SubjectSearchFragment()
            setFragment(searchFragment, itemSelected, instance)
            hideStartPage()
        } else if (id == R.id.nav_news) {
            if (Connection.hasConnection(context)) {
                val downloadNews = DownloadNews(this)
                downloadNews.execute()
            }
        } else if (id == R.id.nav_stats) {
            itemSelected = "Статистика"
            val statsFragment = SubjectSearchFragment()
            setFragment(statsFragment, itemSelected, instance)
            hideStartPage()
        } else if (id == R.id.nav_manual) {
            itemSelected = "Об экзамене"
            val searchFragment = SubjectSearchFragment()
            setFragment(searchFragment, itemSelected, instance)
            hideStartPage()
        } else if (id == R.id.nav_about) {
            val downloadManual = DownloadAboutProject(this)
            downloadManual.execute()
        } else if (id == R.id.nav_check_update) {
            showUpdateMessage("Проверка обновлений", "Проверка обновлений может занять несколько минут. Продолжить?")
        } else if (id == R.id.nav_settings) {
            itemSelected = "Настройки"
            val stFragment = SettingsFragment()
            setFragment(stFragment, null, instance)
            hideStartPage()
        } else if (id == R.id.nav_change_user) {
            itemSelected = "РЕШУ ЕГЭ"
            showAuthorizeMessage("Смена учетной записи", "Вы уверены, что хотите сменить учетную запись?", true)
        } else if (id == R.id.nav_exit) {
            itemSelected = "РЕШУ ЕГЭ"
            showMessage("Выход", "Вы уверены, что хотите выйти?")
        }

        supportActionBar!!.title = itemSelected


        return true
    }

    override fun onDestroy() {
        super.onDestroy()
    }


    fun setFragment(fragment: Fragment, argument: String?, savedInstanceState: Bundle?) {

        if (savedInstanceState == null) {
            val bundle = Bundle()
            bundle.putString("itemSelected", argument)
            fragment.arguments = bundle
        } else {
            savedInstanceState.putString("itemSelected", argument)
            fragment.arguments = savedInstanceState
        }

        val handler = Handler()
        val r = Runnable {
            supportFragmentManager.beginTransaction()
                    .setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.from_left, R.anim.to_right)
                    //.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left)
                    .replace(R.id.container, fragment)
                    .addToBackStack(argument)
                    .commitAllowingStateLoss()
        }
        handler.postDelayed(r, 130)


    }

    private fun clearBackStack() {
        if (fManager.backStackEntryCount > 0) {
            val first = fManager.getBackStackEntryAt(0)
            //fManager.popBackStack("START", FragmentManager.POP_BACK_STACK_INCLUSIVE)
        }
    }


    override fun onFragmentInteraction(subject: String) {
        Log.d("onFrInter", "first")
        if (itemSelected!!.contentEquals("Варианты")) {
            val vFragment = VariantsFragment()
            vFragment.setSubject(subject)
            setFragment(vFragment, null, instance)
        }
        if (itemSelected!!.contentEquals("Каталог заданий")) {
            val tFragment = ThemesFragment()
            tFragment.setSubject(subject)
            setFragment(tFragment, null, instance)
        }
        if (itemSelected!!.contentEquals("Режим экзамена")) {
            val intent = Intent(this, TestsActivity::class.java)
            intent.putExtra("subject_prefix", subject)
            intent.putExtra("section", "Режим экзамена")
            if (Build.VERSION.SDK_INT > 20) {
                val options = ActivityOptions.makeSceneTransitionAnimation(this)
                startActivity(intent, options.toBundle())
            } else {
                startActivity(intent)
            }
        }
        if (itemSelected!!.contentEquals("Теория")) {
            val tFragment = TheoryFragment()
            tFragment.setSubject(subject)
            setFragment(tFragment, null, instance)
        }
        if (itemSelected!!.contentEquals("Поиск")) {
            val intent = Intent(this, SearchTypeActivity::class.java)
            intent.putExtra("subject_prefix", subject)
            intent.putExtra("section", "Поиск")
            if (Build.VERSION.SDK_INT > 20) {
                val options = ActivityOptions.makeSceneTransitionAnimation(this)
                startActivity(intent, options.toBundle())
            } else {
                startActivity(intent)
            }
            //startActivity(intent)
        }
        if (itemSelected!!.contentEquals("Учителю")) {
            val session = Settings().getSession(this)
            if (session.sessionState == SessionState.anonymus) {
                showAuthorizeMessage("Требуется авторизация", "Для просмотра статистики нужно " + "авторизоваться. Перейти к авторизации?", false)
            } else {
                if (Connection.hasConnection(context)) {
                    //open activity with
                    val settings = Settings()

                    val teachFragment = TeacherFragment()
                    teachFragment.setArgs(subject, this)
                    setFragment(teachFragment, "myFr", instance)

                    /*val intent = Intent(this, TeacherActivity1::class.java)
                    intent.putExtra("pref", subject)
                    intent.putExtra("login", settings.getLogin(this))
                    intent.putExtra("password", settings.getPassword(this))
                    startActivity(intent)*/
                }
            }
        }
        if (itemSelected!!.contentEquals("Статистика")) {
            val session = Settings().getSession(this)
            if (session.sessionState == SessionState.anonymus) {
                showAuthorizeMessage("Требуется авторизация", "Для просмотра статистики нужно " + "авторизоваться. Перейти к авторизации?", false)
            } else {
                if (Connection.hasConnection(context)) {
                    val downloadStatistics = DownloadStatistics(this, subject, "session=" + session.session)
                    downloadStatistics.execute()
                }
            }
        }
        if (itemSelected!!.contentEquals("Об экзамене")) {
            if (Connection.hasConnection(context)) {
                val downloadManual = DownloadAboutExam(this, subject)
                downloadManual.execute()
            }
        }
        if (itemSelected!!.contentEquals("О проекте")) {
            if (Connection.hasConnection(context)) {
                val downloadManual = DownloadAboutProject(this)
                downloadManual.execute()
            }
        }

    }

    override fun onFragmentInteraction(itemSelected: String, number: Int) {
        //hideStartPage();
        Log.d("onFrInter", "second")
        Log.d("onFrInter", itemSelected)
        if (itemSelected.contentEquals("Учителю")) {
            val sFragment = SubjectSearchFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Варианты")) {
            val sFragment = SubjectsFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Каталог заданий")) {
            val sFragment = SubjectThemesFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Режим экзамена")) {
            val sFragment = SubjectsFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Теория")) {
            val sFragment = SubjectsTheoryFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Поиск")) {
            val sFragment = SubjectSearchFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Статистика")) {
            val sFragment = SubjectSearchFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Об экзамене")) {
            val sFragment = SubjectSearchFragment()
            setFragment(sFragment, itemSelected, instance)
        }
        if (itemSelected.contentEquals("Настройки")) {
            val sFragment = SettingsFragment()
            setFragment(sFragment, itemSelected, instance)
        }

        this.itemSelected = itemSelected
        hideStartPage()
        supportActionBar!!.setTitle(itemSelected)

    }

    inner class UserLoginTask internal constructor(private val mEmail: String?, private val mPassword: String?, private val savedInstanceState: Bundle?) : AsyncTask<Void, Void, String>() {
        private var serverError = false

        override fun doInBackground(vararg params: Void): String {
            // TODO: attempt authentication against a network service.

            try {
                var data: ByteArray? = null
                var `is`: InputStream? = null
                val parameters = "user=" + mEmail + "&password=" + mPassword + "&" + Protocol.protocolVersion
                val url = URL("https://ege.sdamgia.ru/api?type=login")

                val urlConnection = url.openConnection() as HttpsURLConnection
                urlConnection.requestMethod = "POST"
                urlConnection.doInput = true
                urlConnection.doOutput = true
                urlConnection.setRequestProperty("Content-Length", "" + Integer.toString(parameters.toByteArray().size))
                val os = urlConnection.outputStream
                data = parameters.toByteArray(charset("UTF-8"))
                os.write(data)
                data = null
                urlConnection.connect()
                val responseCode = urlConnection.responseCode

                val baos = ByteArrayOutputStream()
                var str: String? = null
                if (responseCode == 200) {
                    val inputstream = urlConnection.inputStream

                    /* val buffer = ByteArray(8192) // Такого вот размера буфер
                     // Далее, например, вот так читаем ответ
                     var bytesRead: Int
                     //while ((bytesRead = inputstream.read(buffer)) != -1) {
                     while (inputstream.read(buffer).let { bytesRead = it; it != -1 }) {
                         baos.write(buffer, 0, bytesRead)
                     }*/
                    data = inputstream.readBytes()
                    //data = baos.toByteArray()
                    str = String(data, charset("UTF-8"))
                } else {
                }

                val jObject = JSONObject(str)
                try {
                    val jObject2 = jObject.getJSONObject("data")
                    return jObject2.getString("session")
                } catch (e: Exception) {
                    val jObject2 = jObject.getString("error")
                    return ""
                }

            } catch (ioe: IOException) {
                Log.i("errorLOG", ioe.message)
                serverError = true
                return ""
            } catch (jse: JSONException) {
                Log.i("errorLOG", jse.message)
                serverError = false
                return ""
            } catch (np: NullPointerException) {
                serverError = false
                return ""
            }
            /*catch (Exception e) {
                Log.i("errorLOG", e.getMessage());
                serverError = true;
                return "";
            }*/
        }

        override fun onPostExecute(session: String) {
            //showProgress(false, false);
            if (session != "") {
                val sessionObject = Session(session, SessionState.authorized)
                val settings = Settings()
                settings.setSession(sessionObject, context)
                settings.setLoginAndPassword(mEmail!!, mPassword!!, context)
            } else {
                if (serverError) {
                    Toast.makeText(context, "Что-то пошло не так", Toast.LENGTH_SHORT).show()
                    val intent = Intent(context, LoginActivity::class.java)
                    if (Build.VERSION.SDK_INT > 20) {
                        val options = ActivityOptions.makeSceneTransitionAnimation(context as Activity)
                        startActivity(intent, options.toBundle())
                    } else {
                        startActivity(intent)
                    }
                    //startActivity(Intent(context, LoginActivity::class.java), savedInstanceState)
                }
            }
        }
    }

    public override fun onSaveInstanceState(outState: Bundle) {

        outState.putString("itemSelected", itemSelected)
        super.onSaveInstanceState(outState)
    }

    fun createDataBaseIfNotExist() {
        val qdbHelper = QuestionsDataBaseHelper(this, "start_table")
        val db = qdbHelper.writableDatabase
        qdbHelper.close()
    }

    fun hideStartPage() {
        val fab = findViewById<View>(R.id.fab) as FloatingActionButton
        if (fab.visibility != View.GONE) {
            val animation = AnimationUtils.loadAnimation(this, R.anim.slide_out_down)
            fab.startAnimation(animation)
            fab.hide()
        }
    }

    override fun finish() {

        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

    fun checkUpdate() {
        val update = Update(this, false)
        update.doInBackground()
    }

    fun setVersionPreferences() {
        val verPref = getSharedPreferences("version_tests", AppCompatActivity.MODE_PRIVATE)
        val verTheory = getSharedPreferences("theory_tests", AppCompatActivity.MODE_PRIVATE)

        val subject_prefix = resources.getStringArray(R.array.subjects_prefix)
        for (i in subject_prefix.indices) {
            var check = verPref.getString(subject_prefix[i], "null")
            if (check!!.contentEquals("null")) {
                val ed = verPref.edit()
                ed.putString(subject_prefix[i], "0")
                ed.commit()
                Log.d("myLog", "Версия предмета " + subject_prefix[i] + " = null")
            } else
                Log.d("myLog", "Версия предмета " + subject_prefix[i] + " = " + check)
            check = verTheory.getString(subject_prefix[i], "null")
            if (check!!.contentEquals("null")) {
                val ed = verTheory.edit()
                ed.putString(subject_prefix[i], "0")
                ed.commit()
                Log.d("myLog", "Версия предмета " + subject_prefix[i] + " = null")
            }
        }

    }

    fun showMessage(title: String, message: String) {

        val ad = AlertDialog.Builder(this)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setNegativeButton("Да") { dialog, arg1 -> finish() }

        ad.setPositiveButton("Нет") { dialog, arg1 -> }

        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()
    }

    fun showAuthorizeMessage(title: String, message: String, change_user: Boolean) {

        val ad = AlertDialog.Builder(this)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setNegativeButton("Да") { dialog, arg1 ->
            if (change_user) {
                MyDB.removeUser(MyDB.getUser().login)
                val sessionObject = Session("", SessionState.anonymus)
                val settings = Settings()
                settings.setSession(sessionObject, context)
                settings.setLoginAndPassword("", "", context)
            }
            val intent = Intent(context, LoginActivity::class.java)
            if (Build.VERSION.SDK_INT > 20) {
                val options = ActivityOptions.makeSceneTransitionAnimation(this)
                startActivity(intent, options.toBundle())
            } else {
                startActivity(intent)
            }
            //startActivity(intent)
        }

        ad.setPositiveButton("Нет") { dialog, arg1 -> }

        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()
    }

    fun showUpdateMessage(title: String, message: String) {

        val ad = AlertDialog.Builder(context)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setNegativeButton("Да") { dialog, arg1 ->
            if (Connection.hasConnection(context)) {
                val update = Update(this, false)
                update.doInBackground()
            }
        }

        ad.setPositiveButton("Нет") { dialog, arg1 -> }

        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()
    }

    companion object {
        internal var instance: Bundle? = null


        lateinit var user: User

        private val SALT = byteArrayOf(-46, 65, 30, -128, -113, -103, -57, 74, -64, 51, 88, -95, -45, 77, -117, -36, -11, 32, -64, 89)
    }
}
