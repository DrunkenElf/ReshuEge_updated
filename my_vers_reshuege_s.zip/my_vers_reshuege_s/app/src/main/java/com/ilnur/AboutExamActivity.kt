package com.ilnur

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.WebView

class AboutExamActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_exam)

        val manual = intent.getStringExtra("manual")
        val title = intent.getStringExtra("title")

        supportActionBar!!.title = title

        showTheory(manual)
    }

    private fun showTheory(theoryText: String) {
        val showWV = findViewById<View>(R.id.manualView) as WebView
        showWV.settings.builtInZoomControls = true
        showWV.settings.displayZoomControls = false
        showWV.loadDataWithBaseURL(null, theoryText, "text/html", "utf-8", null)
    }
}
