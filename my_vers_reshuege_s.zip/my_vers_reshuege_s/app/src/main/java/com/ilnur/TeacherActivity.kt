package com.ilnur

import android.graphics.Bitmap
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.transition.Slide
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.webkit.WebViewClient
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

import com.bumptech.glide.Glide

import org.jsoup.Connection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

import java.io.ByteArrayInputStream
import java.io.IOException
import java.util.stream.Collector
import java.util.stream.Collectors
import java.util.stream.IntStream


class TeacherActivity : AppCompatActivity() {
    private var pref: String? = null
    private var web: WebView? = null
    private var url: String? = null
    private var manager: CookieManager? = null
    private lateinit var cookies: MutableMap<String, String>
    private lateinit var webClient: com.ilnur.WebViewClient

    private fun setupAnim() {
        if (Build.VERSION.SDK_INT >= 21) {
            val toRight = Slide()
            toRight.slideEdge = Gravity.RIGHT
            toRight.duration = 500

            val toLeft = Slide()
            toLeft.slideEdge = Gravity.LEFT
            toLeft.duration = 500

            /*Slide toTop = new Slide();
            toTop.setSlideEdge(Gravity.TOP);
            toTop.setDuration(500);

            Slide toBot = new Slide();
            toBot.setSlideEdge(Gravity.BOTTOM);
            toBot.setDuration(500);*/

            //когда переходишь на новую
            window.exitTransition = toLeft
            window.enterTransition = toRight

            //когда нажимаешь с другого назад и открываешь со старого
            window.returnTransition = toRight
            window.reenterTransition = toRight

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupAnim()
        setContentView(R.layout.activity_teacher)


        Glide.with(this)
                .load(R.drawable.ball)
                .timeout(100)
                .into(findViewById<View>(R.id.gif_load) as ImageView)

        web = findViewById(R.id.teacher)
        pref = intent.getStringExtra("pref")
        //cont = this;
        url = intent.getStringExtra("url")
        cookies = listToMap(intent.getStringArrayListExtra("keySet"), intent.getStringArrayListExtra("values"))

        if (cookies == null) {
            showMessage("Что-то не так", "Попробуйте зайти снова")
            finish()
        }



        val settings = web!!.settings
        settings.javaScriptEnabled = true
        settings.setAppCacheEnabled(true)
        web!!.settings.loadWithOverviewMode = false
        web!!.settings.useWideViewPort = false
        settings.userAgentString = "Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 XL Build/OPD1.170816.004)" + " AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Mobile Safari/537.36"
        settings.pluginState = WebSettings.PluginState.ON
        settings.loadsImagesAutomatically = true
        settings.supportMultipleWindows()


        val syncManager = CookieSyncManager.createInstance(web!!.context)
        manager = CookieManager.getInstance()
        manager!!.setAcceptCookie(true)
        manager!!.removeSessionCookie()
        Log.d("syncMan", syncManager.toString())
        val gif = findViewById<ImageView>(R.id.gif_load)
        webClient = WebViewClient(web, gif, cookies, this)
        web!!.webViewClient = webClient
        //web!!.webChromeClient = WebChromeClient()

        for ((key, value) in cookies!!) {
            manager!!.setCookie(url,
                    "$key=$value; ")
        }
        CookieSyncManager.getInstance().sync()
        if (!webClient.isFinished)
            web!!.loadUrl(url, cookies)

    }

    override fun onDestroy() {
        webClient.dismissProgressDialog()
        super.onDestroy()
    }




    fun listToMap(keys: List<String>, values: List<String>): MutableMap<String, String>{
        val map: MutableMap<String, String> = mutableMapOf()
        val i = keys.iterator()
        val j = values.iterator()

        while (i.hasNext() || j.hasNext()) map.put(i.next(), j.next())
        return map
    }



    override fun onBackPressed() {
        if (web!!.canGoBack()) {
            web!!.goBack()
        } else {
            super.onBackPressed()
        }
    }

    fun showMessage(title: String, message: String) {
        val ad = AlertDialog.Builder(this)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setNegativeButton("Да") { dialog, arg1 -> }


        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()
    }
}
