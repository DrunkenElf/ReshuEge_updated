package com.ilnur.DownloadTasks

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.util.Log

import org.json.JSONException
import org.json.JSONObject

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL

import javax.net.ssl.HttpsURLConnection

import com.ilnur.Protocol
import com.ilnur.SearchTaskResult
import com.ilnur.utils.StreamReader


class OpenTask(internal var context: Context, internal var subject_prefix: String, internal var taskNumber: String) : AsyncTask<String, Int, JSONObject>() {

    internal lateinit var progress: ProgressDialog
    internal var serverError = false

    override fun onPreExecute() {
        progress = ProgressDialog(context)
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER)

        progress.setMessage("Загрузка задания")

        try {
            progress.show()
            progress.setCancelable(false)

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun doInBackground(vararg strings: String): JSONObject? {
        var task = JSONObject()
        try {

            val response = loadAPI("get_task&data=" + Integer.parseInt(taskNumber), 0)
            Log.i("OPENtask", response)
            if (response == null) {
                serverError = true
            } else {
                val data = JSONObject(response).getString("data")

                if (data == "{}")
                    return null
                task = JSONObject(data)
            }

        } catch (e: NumberFormatException) {
            return null
        } catch (e: JSONException) {
            e.printStackTrace()
            return null
        }

        return task
    }

    override fun onPostExecute(task: JSONObject?) {
        super.onPostExecute(task)
        if (!serverError) {
            try {
                progress.dismiss()
                if (task == null) {
                    showMessage("Ошибка", "Задание не найдено.")
                } else {
                    val intent = Intent(context, SearchTaskResult::class.java)
                    intent.putExtra("body", task.getString("body"))
                    var text = " "
                    try {
                        text = task.getString("text")
                    } catch (e: Exception) {

                    }

                    intent.putExtra("text", text)
                    intent.putExtra("solution", task.getString("solution"))
                    intent.putExtra("id", task.getInt("id").toString())
                    intent.putExtra("task", task.getString("task"))
                    intent.putExtra("type", task.getString("type"))

                    context.startActivity(intent)
                }

            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("myLogs", e.toString())
            }

        } else {
            progress.dismiss()
            showMessage("Ошибка", "Задание не найдено.")
        }
    }

    fun loadAPI(APIRequest: String, id: Int): String? {

        var str: String? = null
        var tryesCount = 0
        while (str == null && tryesCount != 10)
            try {
                tryesCount++
                val url: URL = if (id == 0)
                    URL("https://" + subject_prefix + "-ege.sdamgia.ru/api?type=" + APIRequest + "&" + Protocol.protocolVersion)
                else
                    URL("https://" + subject_prefix + "-ege.sdamgia.ru/api?type=" + APIRequest + id + "&" + Protocol.protocolVersion)
                val urlConnection = url.openConnection() as HttpsURLConnection
                val `in` = BufferedReader(InputStreamReader(urlConnection.inputStream))
                str = StreamReader().readLines(`in`)


            } catch (e: Exception) {
                e.printStackTrace()
            }

        return str
    }

    fun showMessage(title: String, message: String) {

        val ad = androidx.appcompat.app.AlertDialog.Builder(context)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setPositiveButton("Продолжить") { dialog, arg1 -> }

        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()
    }

}
