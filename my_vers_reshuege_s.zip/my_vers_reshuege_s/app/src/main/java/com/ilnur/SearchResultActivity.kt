package com.ilnur

import android.app.ListActivity
import android.os.Build
import android.os.Bundle
import android.transition.Slide
import android.view.Gravity
import android.view.View
import android.widget.ListView

import com.ilnur.Adapters.SearchResultsAdapter
import com.ilnur.DownloadTasks.OpenTask

class SearchResultActivity : ListActivity() {

    internal lateinit var subject_prefix: String
    internal lateinit var results: IntArray
    private fun setupAnim() {
        if (Build.VERSION.SDK_INT >= 21) {
            val toRight = Slide()
            toRight.slideEdge = Gravity.RIGHT
            toRight.duration = 500

            val toLeft = Slide()
            toLeft.slideEdge = Gravity.LEFT
            toLeft.duration = 500

            val toTop = Slide()
            toTop.slideEdge = Gravity.TOP
            toTop.duration = 500

            val toBot = Slide()
            toBot.slideEdge = Gravity.BOTTOM
            toBot.duration = 500

            //WebView.enableSlowWholeDocumentDraw();
            //когда переходишь на новую
            window.exitTransition = toLeft
            window.enterTransition = toRight

            //когда нажимаешь с другого назад и открываешь со старого
            window.returnTransition = toRight
            window.reenterTransition = toRight

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupAnim()
        setContentView(R.layout.activity_search_results)
        results = intent.getIntArrayExtra("results")
        subject_prefix = intent.getStringExtra("subject_prefix")
        val resultsString = arrayOfNulls<String?>(results.size)
        for (i in results.indices) {
            resultsString[i] = results[i].toString()
        }
        val adapter = SearchResultsAdapter(this, resultsString)
        listAdapter = adapter
    }

    override fun onListItemClick(l: ListView, v: View, position: Int, id: Long) {
        if (Connection.hasConnection(this)) {
            val openTask = OpenTask(this, subject_prefix, results[position].toString())
            openTask.execute()
        }
    }
}
