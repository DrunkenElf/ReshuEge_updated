package com.ilnur


object Protocol {
    var protocolVersion = "protocolVersion=1"
}
