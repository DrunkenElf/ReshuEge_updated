package com.ilnur.Session


class Session(var session: String?, var sessionState: SessionState?)
