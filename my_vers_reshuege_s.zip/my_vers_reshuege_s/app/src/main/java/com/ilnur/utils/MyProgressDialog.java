package com.ilnur.utils;

import android.app.ProgressDialog;
import android.content.Context;

public class MyProgressDialog extends ProgressDialog {

    public MyProgressDialog(Context context, int theme) {
        super(context, theme);
    }
}
