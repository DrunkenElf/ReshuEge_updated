package com.ilnur.Session


enum class SessionState {
    authorized,
    anonymus
}
