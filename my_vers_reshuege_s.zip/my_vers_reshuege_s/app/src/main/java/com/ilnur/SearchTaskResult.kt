package com.ilnur

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.widget.Button

class SearchTaskResult : AppCompatActivity(), View.OnClickListener {

    internal lateinit var body: String
    internal lateinit var solution: String
    internal lateinit var task: String
    internal lateinit var type: String
    internal lateinit var id: String
    internal lateinit var text: String
    internal var theoryText: String? = null
    internal lateinit var showSearched: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_theory)
        theoryText = intent.getStringExtra("theory_text")
        showSearched = findViewById<View>(R.id.showSearched) as Button

        if (theoryText == null) {
            body = intent.getStringExtra("body")
            solution = intent.getStringExtra("solution")
            id = intent.getStringExtra("id")
            task = intent.getStringExtra("task")
            type = intent.getStringExtra("type")
            text = intent.getStringExtra("text")

            theoryText = "<b>Задание № " + id + ". Часть " + (if (type.contentEquals("2")) "B" else "C") + ". Тип " + task + "</b><p>" +
                    body

            if (!text.contentEquals("null") && !text.contentEquals(" "))
                theoryText += "<b>Текст</b><p>$text"
            showSearched.setOnClickListener(this)
            showSearched.visibility = View.VISIBLE
        }
        Log.d("myLogs", theoryText)

        showTheory(theoryText)
    }

    private fun showTheory(theoryText: String?) {
        val showWV = findViewById<View>(R.id.theoryView) as WebView
        showWV.settings.builtInZoomControls = true
        showWV.settings.displayZoomControls = false
        showWV.loadDataWithBaseURL(null, theoryText, "text/html", "utf-8", null)
    }


    override fun onClick(v: View) {
        if (showSearched.text.toString().contentEquals("Решение")) {
            showTheory(solution)
            showSearched.text = "Назад"
        } else if (showSearched.text.toString().contentEquals("Назад")) {
            showTheory(theoryText)
            showSearched.text = "Решение"
        }
    }
}
