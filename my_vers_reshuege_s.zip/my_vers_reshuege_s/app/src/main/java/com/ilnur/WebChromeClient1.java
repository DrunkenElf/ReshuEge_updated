package com.ilnur;

import android.webkit.WebChromeClient;

public class WebChromeClient1 extends WebChromeClient {

}
