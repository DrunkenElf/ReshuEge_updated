package com.ilnur.Fragments

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.ListFragment

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ListView
import androidx.core.app.ActivityCompat

import java.util.ArrayList

import com.ilnur.Adapters.ThemesArrayAdapter
import com.ilnur.Connection
import com.ilnur.DataBase.QuestionsDataBaseHelper
import com.ilnur.DownloadTasks.DownloadAllThemesTasks
import com.ilnur.DownloadTasks.DownloadThemesTasks
import com.ilnur.R
import com.ilnur.TestsActivity

class ThemesFragment : ListFragment() {

    internal var subject_prefix: String? = null
    internal var themes = ArrayList<String>()
    internal var themesId = ArrayList<Int>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if (savedInstanceState != null) {
            subject_prefix = savedInstanceState.getString("subject_prefix")
        }
        return inflater.inflate(R.layout.fragment_listview, null)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        try {
            val qdbHelper = QuestionsDataBaseHelper(activity!!, subject_prefix!!)
            val db = qdbHelper.writableDatabase

            val cursor = db.query(subject_prefix!! + "_category_themes", null, null, null, null, null, null)

            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    do {
                        themes.add(cursor.getString(cursor.getColumnIndex("theme_name")))
                        themesId.add(cursor.getInt(cursor.getColumnIndex("theme_id")))
                    } while (cursor.moveToNext())
                }
            } else
                Log.d("myLogs", "Пустой курсор")

            cursor!!.close()
            db.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val themesArray = arrayOfNulls<String>(themes.size)
        for (i in themes.indices) {
            themesArray[i] = themes[i] + "$" + themesId[i]
        }

        val adapter = ThemesArrayAdapter(activity!!, themesArray, subject_prefix!!)
        listAdapter = adapter
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(activity!!, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                val builder = androidx.appcompat.app.AlertDialog.Builder(activity!!)
                builder.setMessage("Для корректного отображения скачанных изображений требуется дать доступ к сохранению файлов.")
                        .setPositiveButton("Продолжить") { dialog, which ->
                            ActivityCompat.requestPermissions(activity!!,
                                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                                    1)
                        }
                builder.show()
            }
        }
    }

    override fun onListItemClick(l: ListView, v: View, position: Int, id: Long) {
        val themeReloadImage = v.findViewById<View>(R.id.themeReloadIcon) as ImageView
        if (themesId[position] != 0) {
            if (themeReloadImage.visibility == View.GONE) {
                val themesArray = arrayOfNulls<String>(themesId.size)
                for (i in themesId.indices) {
                    themesArray[i] = themesId[i].toString()
                }
                showMessage("Отсутствуют задания", "Требуется загрузить задания. Скачать все темы сразу или отдельно выбранную?", subject_prefix, themesId[position].toString(), themesArray)
            } else {
                var pos = 0
                for (i in themesId.indices) {
                    if (themesId[i] == 0 || !themes[i].contains("⚫")) {
                        pos++
                    }
                    if (i == position) {
                        break
                    }
                }
                val intent = Intent(activity, TestsActivity::class.java)
                intent.putExtra("subject_prefix", subject_prefix)
                intent.putExtra("theme_number", themesId[position])
                intent.putExtra("position", pos)
                intent.putExtra("section", "Каталог заданий")
                startActivity(intent)
            }
        }
    }


    fun setSubject(subject: String) {
        subject_prefix = subject
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("subject_prefix", subject_prefix)
        super.onSaveInstanceState(outState)
    }

    fun showMessage(title: String, message: String, prefix: String?, theme: String, themes: Array<String?>) {
        val ad = androidx.appcompat.app.AlertDialog.Builder(activity!!)
        ad.setTitle(title)
        ad.setMessage(message)

        ad.setNegativeButton("Все") { dialog, arg1 ->
            if (Connection.hasConnection(activity!!)) {
                if (activity!!.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                    activity!!.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                } else
                    activity!!.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                val questions = DownloadAllThemesTasks(activity!!, prefix!!, themes)
                questions.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR)
                activity!!.onBackPressed()
            }
        }

        ad.setNeutralButton("Выбранную") { dialog, which ->
            if (Connection.hasConnection(activity!!)) {
                if (activity!!.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                    activity!!.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                } else
                    activity!!.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                val questions = DownloadThemesTasks(activity!!, prefix!!, theme)
                questions.execute()
                activity!!.onBackPressed()
            }
        }

        ad.setPositiveButton("Отмена") { dialog, arg1 -> }

        ad.setCancelable(true)
        ad.setOnCancelListener { }

        ad.show()

    }

}
